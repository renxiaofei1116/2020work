<template>
  <div>改变mima</div>
</template>
<script>
export default {
  name: "ChangePasswd",
  components: {}
};
</script>