# test1-vue

拉勾视频站前端页面：已完成！



## 项目安装
```
npm install
```

### 编译并运行项目
```
npm run serve
```

### 编译重构项目
```
npm run build
```
